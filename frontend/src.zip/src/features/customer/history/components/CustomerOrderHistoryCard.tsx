"use client";

import Image from "next/image";
import type { OrderHistoryStatus } from "@/shared/orders/history/types/order-history.types";
import type { CustomerOrderHistoryItem } from "../types/customer-order-history.types";

type CustomerOrderHistoryCardProps = {
  order: CustomerOrderHistoryItem;
};

const statusLabels: Record<OrderHistoryStatus, string> = {
  pending: "در انتظار تایید",
  preparing: "در صف آماده سازی",
  ready: "آماده تحویل",
  delivered: "تحویل شده",
  cancelled: "لغو شده",
};

const statusClasses: Record<OrderHistoryStatus, string> = {
  pending: "text-yellow-700",
  preparing: "text-emerald-700",
  ready: "text-blue-700",
  delivered: "text-emerald-700",
  cancelled: "text-red-600",
};

function resolveImageSrc(src?: string) {
  const value = src?.trim();

  if (!value || value === "undefined" || value === "null") {
    return "/images/cake.webp";
  }

  if (
    value.startsWith("/") ||
    value.startsWith("http://") ||
    value.startsWith("https://") ||
    value.startsWith("data:image/") ||
    value.startsWith("blob:")
  ) {
    return value;
  }

  return `/images/${value}`;
}

export default function CustomerOrderHistoryCard({
  order,
}: CustomerOrderHistoryCardProps) {
  const imageSrc = resolveImageSrc(order.foodImage);

  return (
    <article className="w-full overflow-hidden rounded-md border border-gray-300 bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
      <div className="relative aspect-square w-full overflow-hidden bg-[#FDF7F2]">
        <Image
          src={imageSrc}
          alt={order.foodTitle}
          fill
          className="object-cover"
        />
      </div>

      <div className="space-y-1.5 px-2 py-2 text-center">
        <h3 className="truncate text-xs font-extrabold text-gray-950 sm:text-sm">
          {order.foodTitle}
        </h3>

        <p className="truncate text-[11px] font-medium text-gray-600">
          {order.chefName || "آشپز دیگچه"}
        </p>

        <p className="text-[11px] font-medium text-gray-700">
          مقدار: {order.quantity}
        </p>

        <p className={`text-[11px] font-bold ${statusClasses[order.status]}`}>
          {statusLabels[order.status]}
        </p>
      </div>
    </article>
  );
}