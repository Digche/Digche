"use client";

import type { ReactNode } from "react";
import SearchInput from "@/shared/components/SearchInput";
import type { OrderHistoryGroupData } from "../types/order-history.types";
import OrderHistoryGroup from "./OrderHistoryGroup";

type OrderHistoryScreenProps<TOrder extends { id: number | string }> = {
  searchTerm: string;
  onSearchTermChange: (value: string) => void;
  groups: OrderHistoryGroupData<TOrder>[];
  renderCard: (order: TOrder) => ReactNode;
  profileBadge?: ReactNode;
  header?: ReactNode;
  searchPlaceholder?: string;
  emptyTitle?: string;
  emptyDescription?: string;
  gridClassName?: string;
};

export default function OrderHistoryScreen<
  TOrder extends { id: number | string },
>({
  searchTerm,
  onSearchTermChange,
  groups,
  renderCard,
  profileBadge,
  header,
  searchPlaceholder = "جست و جو در سفارش ها...",
  emptyTitle = "سفارشی برای نمایش وجود ندارد",
  emptyDescription = "هنوز سفارشی ثبت نشده یا نتیجه‌ای برای جست‌وجوی شما پیدا نشد.",
  gridClassName,
}: OrderHistoryScreenProps<TOrder>) {
  return (
    <section className="relative min-h-[calc(100vh-4rem)]">
      {profileBadge && (
        <div className="absolute left-0 top-0 hidden md:block">
          {profileBadge}
        </div>
      )}

      <div className="mx-auto flex w-full max-w-5xl flex-col items-center">
        {header}

        <div className="mb-10 mt-2 w-full max-w-md">
          <SearchInput
            value={searchTerm}
            onChange={onSearchTermChange}
            placeholder={searchPlaceholder}
            className="w-full"
          />
        </div>

        <div className="w-full max-w-5xl rounded-md border border-gray-300 bg-white px-5 py-5 shadow-sm md:max-h-[650px] md:overflow-y-auto">
          {groups.length === 0 ? (
            <div className="flex min-h-[260px] items-center justify-center text-center">
              <div>
                <h2 className="text-lg font-bold text-gray-800">
                  {emptyTitle}
                </h2>

                <p className="mt-2 text-sm text-gray-500">
                  {emptyDescription}
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {groups.map((group) => (
                <OrderHistoryGroup
                  key={group.key}
                  title={group.label}
                  orders={group.orders}
                  renderCard={renderCard}
                  gridClassName={gridClassName}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}