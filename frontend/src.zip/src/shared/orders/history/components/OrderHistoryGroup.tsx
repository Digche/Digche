"use client";

import type { ReactNode } from "react";

type OrderHistoryGroupProps<TOrder extends { id: number | string }> = {
  title: string;
  orders: TOrder[];
  renderCard: (order: TOrder) => ReactNode;
  gridClassName?: string;
};

export default function OrderHistoryGroup<
  TOrder extends { id: number | string },
>({
  title,
  orders,
  renderCard,
  gridClassName = "grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4",
}: OrderHistoryGroupProps<TOrder>) {
  return (
    <section className="overflow-hidden rounded-md border border-gray-300 bg-white">
      <div className="flex min-h-10 items-center justify-end border-b border-gray-200 px-5">
        <h2 className="text-sm font-extrabold text-gray-950 sm:text-base">
          {title}
        </h2>
      </div>

      <div className="p-4">
        <div className={gridClassName}>
          {orders.map((order) => (
            <div key={order.id}>{renderCard(order)}</div>
          ))}
        </div>
      </div>
    </section>
  );
}